$(document).ready(function(){
    


//$("#sub").click(function() {
//    //var toAdd = $("textarea[name=message]").val();
////     $('#messages').append("<p>"+toAdd+"</p>");
////        $("textarea[name=message]").val(' ');
//
//    var data = $("#forForm: text").serializeArray();      
//    $.post($("#forForm").attr("action"), data, function(info){$("#messages").html(info);});
//    clearInput();
//}),
//
//
//$("#forForm").submit(function(){
//    return false;
//}),

//function clearInput(){
//    $("#forForm : textarea").each(function() {
//        $(this).val('');
//    })
//}
   
//$('.vote').click(function() {
//    $(this).toggleClass('on');
//});
//
//$('.dVote').click(function() {
//    $(this).toggleClass('on');
//});
    
$('#sort').accordion({collapsiable : true, active: false});

});


 