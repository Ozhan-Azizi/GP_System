<?php

require_once 'all.php';
if(isset($_POST['gethighrate']))
{
    $theTitle = $_POST['title'];
    $forComments = 1;
}

require_once 'viewThread.php';

?>

