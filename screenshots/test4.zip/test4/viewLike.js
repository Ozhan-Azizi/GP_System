//(function(d,e,s){
//    if(d.getElementById("likebtn_wjs"))
//    {
//        return;
//    }
//    a=d.createElement(e);
//    m=d.getElementsByTagName(e)[0];
//    a.async=1;
//    a.id="likebtn_wjs";
//    a.src=s;
//    m.parentNode.insertBefore(a, m)
//    })
//
//(document,"script","//w.likebtn.com/js/w/widget.js");