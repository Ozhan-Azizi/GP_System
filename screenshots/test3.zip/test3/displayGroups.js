$(function(){
    

$("#shareToGroup").click(function(){
    $("#groups").slideToggle('fast');
});
});
