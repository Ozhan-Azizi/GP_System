$(document).ready(function(){
    $('#sort').accordion({collapsible: true, active: false});
});